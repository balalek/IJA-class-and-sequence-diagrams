package com.javaprojekt;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        //FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("hello-view.fxml"));
        //Scene scene = new Scene(fxmlLoader.load(), 800, 600);

        Parent root = FXMLLoader.load(getClass().getResource("class-diagram.fxml"));
        Scene scene = new Scene(root);

        stage.setTitle("Class Diagram");

        //stage.setFullScreen(true);

        stage.setScene(scene);
        stage.show();
    }

        /*public void start(Stage primaryStage) throws Exception {
        final Group root = new Group();
        primaryStage.setResizable(false);
        Scene scene = new Scene(root, 400,80);
        primaryStage.setScene(scene);

        //rect.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>()
        scene.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
        @Override public void handle(MouseEvent event) {
              Circle circle = new Circle(event.getSceneX(), event.getSceneY(),30);
              circle.setFill(Color.YELLOW);
              root.getChildren().add(circle);
        }
        });
        //root.getChildren().add(circle);
        primaryStage.show();

    }*/

    public static void main(String[] args) {
        launch();
    }
}