package com.javaprojekt;

import com.uml.ClassDiagram;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;

public class ClassDiagramController {

    @FXML
    Button TwoRowClass;

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Pane classPane;

    @FXML
    private AnchorPane classDiagram;

    public void classDiagram(){
        ClassDiagram d = new ClassDiagram("Class Diagram");
    }

    public void InsertTwoRowClass(ActionEvent event){
        /*Label lbl1 = new Label("Ahoj");
        Label lbl2 = new Label("Sbohem");
        classPane.getChildren().add(lbl1);
        classPane.getChildren().add(lbl2);*/

        scene.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override public void handle(MouseEvent event) {
                Circle circle = new Circle(event.getSceneX(), event.getSceneY(),30);
                circle.setFill(Color.YELLOW);
                classPane.getChildren().add(circle);
            }
        });

    }

    public void SwitchToSeqDiagram(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("sequence-diagram.fxml"));
        root = loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }


}