Cílem projektu je načítat, modifikovat a ukládat 1 diagram tříd a k němu více sekvenčních diagramů v GUI.

Členové týmu:
    Martin Baláž (xbalaz15)
    Josef Kuba (xkubaj03)

Aplikace se momentálně překládá a spouští v prostředí IntelliJ IDEA pomocí maven makra "javafx:run".
Pro vyčistění adresářové struktury slouží příkaz clean z maven Lifecyclu.
Vytvoření a spouštění výsledného jar souboru momentálně není možné.

Verze:	Java SDK 17
	JavaFX 17
