wget -P . https://raw.githubusercontent.com/balalek/IJA-library/main/library.zip
unzip library.zip
rm library.zip